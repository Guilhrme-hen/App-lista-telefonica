package com.example.listatelefonica.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.listatelefonica.database.ContatoRepository
import com.example.listatelefonica.model.Contato

class NovoContatoViewModel(application: Application) : AndroidViewModel(application) {

    private val novoContacto = MutableLiveData<Long>()
    private val repository = ContatoRepository(application)

    fun novoContacto(): LiveData<Long> {
        return novoContacto
    }

    fun insert(nome: String, email: String, endereco: String, telefone: String, imagemId: Int) {
        novoContacto.value = repository.insert(
            Contato(
                nome = nome,
                email = email,
                endereco = endereco,
                telefone = telefone,
                imagemId = imagemId
            )
        )
    }

}